// vitest.config.ts

import path from 'node:path';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vitest/config';

export default defineConfig({
	plugins: [react()],
	test: {
		environment: 'jsdom',
		globals: true,
		setupFiles: ['./vitest.setup.ts'],

		exclude: ['**/e2e/**', '**/tests/**', '**/node_modules/**'],
	},
	resolve: {
		alias: {
			'@': path.resolve(__dirname, './'),
		},
	},
});
